curl -F "file=@C:\Users\qaiu\Desktop\real\lz-web\web\src\main\resources\logback.xml" -i -XPOST  127.0.0.1:6400/demo/XXX/XXX

curl -F "file=@C:\Users\qaiu\Desktop\3.csv" -i -XPOST  127.0.0.1:6400/demo/XXX/XXX

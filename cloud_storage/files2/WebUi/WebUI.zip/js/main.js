document.addEventListener('DOMContentLoaded', () => {
    fetch('data/list.json')
        .then(response => response.json())
        .then(data => {
            const sidebar = document.getElementById('sidebar');
            data.lists.forEach((item, index) => {
                const div = document.createElement('div');
                div.textContent = item;
                div.addEventListener('click', () => loadContent(`data/content${index + 1}.json`));
                sidebar.appendChild(div);
            });
        })
        .catch(error => console.error('Error loading JSON:', error));
});

async function loadContent(file) {
    try {
        const response = await fetch(file);
        const data = await response.json();
        document.getElementById('image').src = data.image;
        document.getElementById('info1').textContent = data.info1;
        document.getElementById('info2').textContent = data.info2;
        
        // 检查JSON数据中是否包含名为"function"的键
        if (data.function && Array.isArray(data.function)) {
            // 如果有对应函数，调用它并展开参数数组
            list(...data.function);
        } else {
            console.error('Function not found or not an array.');
        }

        // 检查JSON数据中是否包含名为"function"的键
        if (data.lanzoul_url && Array.isArray(data.lanzoul_ur)) {
            // 如果有对应函数，调用它并展开参数数组
            list(...data.lanzoul_ur);
        } else {
            console.error('lanzoul_ur not found or not an array.');
        }
    } catch (error) {
        console.error('Error loading content JSON:', error);
    }
}
